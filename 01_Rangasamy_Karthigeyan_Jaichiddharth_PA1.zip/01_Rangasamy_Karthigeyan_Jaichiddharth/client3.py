import socket

IP = socket.gethostbyname(socket.gethostname())
PORT = 4456
ADDR = (IP, PORT)
FORMAT = "utf-8"
SIZE = 1024

def main():
    client1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client1.connect(ADDR)

    while True:
        data1 = client1.recv(SIZE).decode(FORMAT)
        cmnd, msg = data.split("@")

        if cmnd == "DISCONNECTED":
            print(f"[SERVER]: {msg}")
            break
        elif cmnd == "OK":
            print(f"{msg}")

        data1 = input("> ")
        data1 = data.split(" ")
        cmnd = data[0]

        if cmnd == "HELP":
            client1.send(cmnd.encode(FORMAT))
        elif cmnd == "LOGOUT":
            client1.send(cmnd.encode(FORMAT))
            break
        elif cmd == "LIST":
            client1.send(cmnd.encode(FORMAT))
        elif cmd == "DELETE":
            client1.send(f"{cmd}@{data[1]}".encode(FORMAT))
        elif cmnd == "UPLOAD":
            path = data1[1]

            with open(f"{path}", "r") as f:
                text = f.read()

            filename = path.split("/")[-1]
            send_data = f"{cmd}@{filename}@{text}"
            client1.send(send_data.encode(FORMAT))

    print("Disconnected from the server.")
    client1.close()

if __name__ == "__main__":
    main()
